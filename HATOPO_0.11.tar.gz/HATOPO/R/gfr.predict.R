#' gfr.predict: Generates predictions from a GFR-type GLM object.
#' @description Uses new data provided by the user to generate predictions from a gfr model object.
#' @author Jason Matthiopoulos
#' @param model The gfr model object to be used
#' @param newdata The data frame containing the new explanatory variable data
#' @param type The type of prediction required. As described in \link{predict.glm}
#' @param se.fit Whether standard errors are required for the predictions.
#' @return \code{predictions} The predictions generated
#' @return \code{expectations} The expectations calculated for the \code{newdat} dataframe
#' @export
#' @references Matthiopoulos et al. (2011) Generalized functional responses for species distributions. Ecology 92 (3), 583-589
#' @seealso \link{gfr}

gfr.predict<-function(model, newdata=NULL, type = c("link", "response", "terms"), se.fit = FALSE)
{

  # MAIN CODE

  # Creating extended data frame by calculating expectations
  order<-model$order # Order to be used for expectations (Inherrited from model object)
  mod<-model$model # Extract the GLM part of the gfr object (Including the interactions)
  formula<-model$formula # Extract the basic formula of the gfr (without the interactions)
  addexp<-model$addexp
  newdat<-newdata # Creates copy of data frame to be augmented with expectations

  block<-as.factor(eval(parse(text=paste("newdata$",model$blockName, sep=""))))
  vs<-c(attr(terms(formula),"term.labels")) #extracts the names of all the formula terms (including quadratics)
  y<-all.vars(formula)[1] # Extracts the response variable
  mainVars<-all.vars(formula)[-1] # Extracts the main effects

  cats<-levels(block)
  exps<-as.data.frame(matrix(vector(), nrow=length(cats), ncol=0, dimnames=list(cats,c())))

  # Expectations
  expVars<-c()
  for(or in 1:order)
  {
    for(i in 1:length(mainVars))
    {
      expName<-paste("M",or,"_",mainVars[i], sep="")
      expVars<-c(expVars, expName)
      rawCol<-eval(parse(text=paste("newdata$",mainVars[i])))
      pivot<-tapply(rawCol^or, block, mean)
      exps[,paste(expName)]<-pivot
      newCol<-pivot[block]
      newdat[,paste(expName)]<-newCol
    }
  }
  i<-0
  while(i<length(addexp))
  {
    i<-i+1
    expName<-paste("M1_",addexp[i], sep="")
    expVars<-c(expVars, expName)
    rawCol<-eval(parse(text=paste("newdata$",addexp[i])))
    pivot<-tapply(rawCol, block, mean)
    exps[,paste(expName)]<-pivot
    names(newdat)<-gsub(addexp[i], expName, names(newdat))
  }


  # Generate predictions from glm object
  return(list("predictions"=predict(mod, newdat, type=type, se.fit=se.fit), "expectations"=exps))

}
