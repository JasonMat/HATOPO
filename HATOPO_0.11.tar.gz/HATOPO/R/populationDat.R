#' populationDat
#'
#' @docType data
#' @usage populationDat
#' @details  Population change data from different sampling instances. Derived from individual based simulation described in Matthiopoulos et al. 2015
#' @format A dataframe
#' @details This data frame carries information on population change from 400 sampling instances. The habitat composition and usage that is contained in the data frame \link{habitatDat} corresponds to the same sampling instances. \code{N2} is the current population size, \code{N1} is last year's population size. Average measurements for the environmental covariates are included so that a non-spatial model can be fitted to these data (see how these are used in the worked example in the \link{HATOPO} help file.)
#' @keywords datasets
#' @references Matthiopoulos et al. (2015) Establishing the link between habitat selection and animal population dynamics. Ecological Monographs 85 (3), 413-436
"populationDat"
