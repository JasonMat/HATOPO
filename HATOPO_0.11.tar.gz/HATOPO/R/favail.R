
#' favail: Gaussian approximation of habitat availability

#' @description This is a wrapper function for mclust, specified to the needs of HATOPO. It estimates a Gaussian approximation of habitat availability from a sample of environmental space. Environmental data from multiple sampling instances can be used assuming that the data are blocked by sampling instance.
#' @author Jason Matthiopoulos
#' @param data A data frame of environmental measurements (the columns) at different spatial locations (the rows).
#' @param blocking An ordered vector describing the sampling instances from which different rows come from
#' @param G The number of gausian components to be used for the approximating mixture
#' @param verbose Switches on and off a progress bar for larger data sets
#' @return Statistical summaries of the Gaussian mixture making up the approximation of environmental space
#' @export
favail<-function(data, blocking=NULL, G=30, verbose=T)
{
  if(verbose==T) bar<-txtProgressBar(0, 100, style=3)
  jv<-unique(blocking) # Extracts unique values of blocking index
  jvmax<-length(jv)
  summaries<-vector("list", jvmax)

  for(i in 1:jvmax) # loops through the blocks
  {
    if(verbose==T) setTxtProgressBar(bar,100*i/jvmax)
    edat<-data[blocking==jv[i],]
    eclust<-Mclust(edat, G=G, modelNames=c("EEI"))  # Application of Gaussian clustering with G kernels
    mus<-eclust$parameters$mean  # Extraction of estimated kernel means
    var<-diag(eclust$parameters$variance$Sigma)   # Extraction of estimated kernel variance
    ws<-eclust$parameters$pro  # Extraction of estimated kernel weights
    summaries[[i]]<-list("mus"=mus, "var"=var, "ws"=ws)
  }
  if(verbose==T) close(bar)
  return(summaries)
}
