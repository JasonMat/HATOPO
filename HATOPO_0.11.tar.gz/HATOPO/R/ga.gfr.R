
#' ga.gfr: Combined coefficients from a GFR model and a data frame of expectations.
#' @description Generalised functional responses (GFRs) describe the response of organisms to different habitats as a function of the availability of all habitats within the organisms' reach. In the GFR implementation this translates to main effects (e.g. temperature, altitude, resource availability) at thelocation of the organism, the (1st or higher order) expectations of the main effects in the viscinity of the organism and the pairwise interactions between those.
#' @author Jason Matthiopoulos
#' @param model A GFR model formula either user-defined, or generated from \code{\link{gfr}}
#' @param expectations The data frame of expectations (one row for each sampling instance)
#' @return A data frame of gamma coefficients, one for each main (linear or quadratic) effect in the GFR model
#' @details The general form of the \code{\link{gfr}} is
#' @details \deqn{y=a_{0}+a_{1}x_{1}+a_{2}x_{2}+b_{1}\bar{x}_{1}+b_{2}\bar{x}_{2}+a_{1,1}x_{1}\bar{x}_{1}+a_{1,2}x_{1}\bar{x}_{2}+a_{2,1}x_{2}\bar{x}_{1}+a_{2,2}x_{2}\bar{x}_{2}}
#' @details Therefore, to obtain predictions from this model for any particular sampling instance we can think of this as a glm whose coefficients are expressed as functions of expectations, such that
#' @details \deqn{y=\gamma_{0}+\gamma_{1}x_{1}+\gamma_{2}x_{2}}
#' @details for the three new coefficients
#' @details \deqn{\gamma_{0}=a_{0}+b_{1}\bar{x}_{1}+b_{2}\bar{x}_{2}}
#' @details \deqn{\gamma_{1}=a_{1}+a_{1,1}\bar{x}_{1}+a_{1,2}\bar{x}_{2}}
#' @details \deqn{\gamma_{2}=a_{2}+a_{2,1}\bar{x}_{1}+a_{2,2}\bar{x}_{2}}
#' @details This function calculates the new coefficients gamma in the general case of the \eqn{n^{th}} order expectation from a gfr object.
#' @export
#' @references Matthiopoulos et al. (2011) Generalized functional responses for species distributions. Ecology 92 (3), 583-589

# FUNCTION:
# Generates the combined regression coefficients from a GFR model object
ga.gfr<-function(model, expectations)
{

  termNames<-c(attr(terms(model),"term.labels"))
  modTerms<-all.vars(formula(model))[-1] # Extracts names of main and expectation variables
  momPos<-grep(expression("M\\d_"), modTerms) # Extracts positions of expectation variables
  quadPos<- grep("^2)", termNames, fixed=TRUE)
  mainNames<-modTerms[-momPos] # Names of main variables
  ixs<-sort.int(nchar(mainNames), decreasing=T, index.return=T)$ix # Finds positions of longer to shorter strings
  mainNames<-mainNames[ixs] # Re-arranges from long to short names to avoid dealing first with strings that are subsets of later ones
  interPos<-grep(":", termNames, fixed=TRUE)
  quadNames<-termNames[setdiff(quadPos, interPos)] # Names of quadratic variables (excluding occurences in interatcions)
  ixs<-sort.int(nchar(quadNames), decreasing=T, index.return=T)$ix # Finds positions of longer to shorter strings
  quadNames<-quadNames[ixs] # Re-arranges from long to short names to avoid dealing first with strings that are subsets of later ones
  momNames<-modTerms[momPos] # Names of expectation variables
  NumberQuad<-length(quadNames)
  NumberMain<-length(mainNames)
  # Creates structure to store the combined coefficients
  gas<-c("intercept", mainNames, quadNames)
  ga<-data.frame(matrix(vector(), nrow=nrow(expectations), length(gas)),stringsAsFactors=TRUE)
  rownames(ga)<-rownames(expectations)
  colnames(ga)<-gas


  termDum<-termNames
  # Deal with 2nd order terms
  ct<-1+NumberMain+1 # Starting position of loop for quadratic terms
  while(ct<=1+NumberMain+NumberQuad)
  {
    expr<- colnames(ga)[ct] # Extracts name of current quadratic effect
    posEf<-grep(expr, termDum, fixed=TRUE) # Finds names of terms that contain it
    coefs<-model$coefficients[termDum[posEf]] # Extracts the model coefficients for these terms

    # Drops the expectation columns that are not being used by the model formula
    nacf<-names(coefs)
    nacf<-gsub(nacf[1], "", nacf, fixed=TRUE)
    nacf<-gsub(":", "", nacf, fixed=TRUE)[-1]
    usedMoms<-match(nacf, names(expectations))

    ga[,expr]<-as.matrix(cbind("intercept"=1, expectations[,usedMoms]))%*%as.matrix(coefs) # Calculates the gammas of this quadratic term for different sampling instances
    termDum<-termDum[-posEf]
    ct<-ct+1
  }

  # Deal with 1st order terms
  ct<-2 # Starting position of loop for main terms (starts after the intercept)
  while(ct<=1+NumberMain)
  {
    expr<- colnames(ga)[ct] # Extracts name of current main effect
    tDum<-termDum
    for(i in 1:length(momNames)) { tDum<-gsub(momNames[i], "", tDum)}
    posEf<-grep(expr, tDum, fixed=TRUE) # Finds names of terms that contain itgsub(eval(expression(paste("M\\d_",expr, sep=""))), "", termDum)
    coefs<-model$coefficients[termDum[posEf]] # Extracts the model coefficients for these terms

    # Drops the expectation columns that are not being used by the model formula
    nacf<-names(coefs)
    usedMoms<-all.vars(as.formula(paste("y~",paste(nacf, collapse="+"))))[-c(1,2)]

    ga[,expr]<-as.matrix(cbind("intercept"=1, expectations[,usedMoms]))%*%as.matrix(coefs) # Calculates the gammas of this main term for different sampling instances
    termDum<-termDum[-posEf]
    ct<-ct+1
  }

  # Deal with Intercept
  expr<-"intercept"
  coefs<-model$coefficients[c("(Intercept)", termDum)]
  nacf<-names(coefs)
  usedMoms<-all.vars(as.formula(paste("y~",paste(nacf, collapse="+"))))[-c(1,2)]
  ga[,expr]<-as.matrix(cbind("intercept"=1, expectations[,usedMoms]))%*%as.matrix(coefs) # Calculates the gammas of the intercept term for different sampling instances

  return(list("gammas"=ga, "mainNames"=mainNames))
}
