#' gfr:Generates and fits a GFR-type GLM object.
#' @description Generalised functional responses (GFRs) describe the response of organisms to different habitats as a function of the availability of all habitats within the organisms' reach.
#' @author Jason Matthiopoulos
#' @param formula The basic glm formula involving just the main effects
#' @param data The data frame of response and explanatory variable data
#' @param family The likelihood function to be used for fitting
#' @param blockName The name of a blocking factor in the data frame indicating the membership of each row to a sampling instance
#' @param addexp Additional explanatory variables that represent values applying uniformly to an entire sampling instance
#' @param order The required order of the momements to be calculated for the GFR
#' @param step Whether to apply stepwise model selection to reduce the terms in the model (default is FALSE)
#' @param blockName The name of the blocking factor in the dataframe
#' @param expFlag Sometimes (e.g. in use-availability designs) only the availability points are required to calculate the expectations
#' @return The fitted gfr model. Containing the following arguments:
#' @return \code{model} The glm model object fitted to the data
#' @return \code{expectations} The calculated expectations from the data
#' @return \code{order} The requested order of expectations
#' @return \code{formula} The basic formula (not containing interactions)
#' @export
#' @details Resource selection functions (RSFs) and other related methods aim to detect correlates of space-use. However, an empirical model fit to data from one place or time is unlikely to capture species responses under different conditions because organisms respond nonlinearly to changes in habitat availability. This phenomenon is known as a functional response in resource selection. Generalized Functional Responses (GFRs) extend the transferrability of the RSF approach. by using data from several sampling instances (ideally, characterized by diverse profiles of habitat availability). By modeling the regression coefficients of the underlying RSF as functions of availability, GFRs can account for environmental change and thus predict population distributions in new environments. This function generates and fits a GFR-type GLM object.The data must be blocked by sampling instance (see \code{block} argument). The GFR model comprises the main explanatory terms provided by the \code{formula}, supplemented by their instance-specific expectations and all the pairwise interactions between the main terms and the expectations in the model. Higher order expectations are specified via the argument \code{order}.
#' @details In the case of a standard Resource Selection Function, the relationship between habitat usage y and habitat variables \eqn{x_{1}, x_{2}} is simply
#' @details \deqn{y=a_{0}+a_{1}x_{1}+a_{2}x_{2}}
#' @details Extending this into a Generalised Functional Response requires the introduction of expectations from the marginal distribution of each explanatory variable (say \eqn{\bar{x}_{1}, \bar{x}_{2}}into the formula, as well as every pairwise interaction between main effects and expectations:
#' @details \deqn{y=a_{0}+a_{1}x_{1}+a_{2}x_{2}+b_{1}\bar{x}_{1}+b_{2}\bar{x}_{2}+a_{1,1}x_{1}\bar{x}_{1}+a_{1,2}x_{1}\bar{x}_{2}+a_{2,1}x_{2}\bar{x}_{1}+a_{2,2}x_{2}\bar{x}_{2}}
#' @details Better performance can be achieved out of the GFR by including higher order expectations and their interactions with the main terms, but this becomes unwieldy to do by hand.
#' @references Matthiopoulos et al. (2011) Generalized functional responses for species distributions. Ecology 92 (3), 583-589
#' @seealso \link{gfr.predict}


gfr<-function(formula, data, family, blockName, expFlag=NULL, addexp=NULL, order=1, step=FALSE, offset=NULL)
{

  block<- as.factor(eval(parse(text=paste("data$",blockName))))
  vs<-c(attr(terms(formula),"term.labels")) #extracts the names of all the formula terms (including quadratics)
  y<-all.vars(formula)[1] # Extracts the response variable
  mainVars<-all.vars(formula)[-1] # Extracts the main effects
  newdata<-data # Creates dataframe that will be augmented with the expectations

  cats<-levels(block)
  exps<-as.data.frame(matrix(vector(), nrow=length(cats), ncol=0, dimnames=list(cats,c())))

  # Expectations
  if(length(expFlag)==0) expFlag=rep(T, length(blockName))
  expVars<-c()
  for(or in 1:order)
  {
    for(i in 1:length(mainVars))
    {
      expName<-paste("M",or,"_",mainVars[i], sep="")
      expVars<-c(expVars, expName)
      rawCol<-eval(parse(text=paste("data$",mainVars[i],"[expFlag]")))
      pivot<-tapply(rawCol^or, block[expFlag], mean)
      exps[,paste(expName)]<-pivot
      newCol<-pivot[block]
      newdata[,paste(expName)]<-newCol
    }
  }

  i<-0
  while(i<length(addexp))
  {
    i<-i+1
    expName<-paste("M1_",addexp[i], sep="")
    expVars<-c(expVars, expName)
    rawCol<-eval(parse(text=paste("data$",addexp[i])))
    pivot<-tapply(rawCol, block, mean)
    exps[,paste(expName)]<-pivot
    names(newdata)<-gsub(addexp[i], expName, names(newdata))

  }

  # Generation of gfr formula
  eMain<-paste(vs, collapse="+")
  eExp<-paste(expVars, collapse="+")
  txt<-paste(y,"~(",eMain,")*(",eExp,")", sep="")


  newformula<-as.formula(txt)
  newformula<-update(newformula, newformula)

  # Model fitting and selection
  modFull<-glm(newformula, data=newdata, family=family, offset=offset)
  mod<-modFull
  if(step==TRUE)
  {
    modMains<-glm(formula(paste(y,"~",paste(mainVars, collapse="+"))), data=newdata, family=family)
    mod<-step(modFull, direction="both",scope=list(upper=modFull,lower=modMains))
  }
  return(list("model"=mod,"expectations"=exps, "order"=order, "formula"=formula, "blockName"=blockName, "addexp"=addexp))

}
