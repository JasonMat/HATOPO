#' habitatDat
#'
#' @docType data
#' @usage habitatDat
#' @details  Habitat use data from different sampling instances. Derived from individual based simulation described in Matthiopoulos et al. 2015. The code that generated these data can be found at the supplementary material for this paper \url{http://dx.doi.org/10.1890/14-2244.1.sm}.
#'
#' @details  The columns in the data frame are:
#' @details  \code{id}: The sampling instance ID. This refers to a snapshot of space at a point in time during which sampling took place. Space use data collected during sampling instance may either originate from a single individual or a population of animals. The assumption is that all of the animals generating the usage data could have accessed all of the space included in the sampling instance.
#' @details  \code{food, temp}: Covariate values that vary by location within a sampling instance. Each location in the spatial extent of the instance has characteristic attributes (here, just food and temperature, but any number of biologically relevant covariates may be included).
#' @details  \code{N}: the population density associated with the entire sampling instance. This is a covariate that applies uniformly to all the measurements within the sampling instance. Such instance-specific covariates may include variables whose values are not known at a high spatial resolution but which may nevertheless have explanatory power for the usage data
#' @details  \code{use}: A count of animals in different grid cells.
#'
#' @format A dataframe
#' @keywords datasets
#' @references Matthiopoulos et al. (2015) Establishing the link between habitat selection and animal population dynamics. Ecological Monographs 85 (3), 413-436
"habitatDat"
